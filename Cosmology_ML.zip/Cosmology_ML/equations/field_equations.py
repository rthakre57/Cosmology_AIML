"""Cosmological model interface.

IMPORTANT:
The functions below provide background kinematics for a phenomenological
bounce, not a derivation/solution of f(R,T) gravitational field equations.
Replace `field_equation_residuals` with residuals derived from your exact
action, matter Lagrangian, metric, and conventions before scientific use.
"""
from dataclasses import dataclass
import numpy as np
from simulation.scale_factor import bounce_background

@dataclass(frozen=True)
class ModelParameters:
    a_b: float = 1.0
    gamma: float = 0.5
    lam: float = 0.1  # placeholder coupling parameter; not used by bounce kinematics

def background(t, params: ModelParameters):
    """Return phenomenological background kinematics on time t."""
    return bounce_background(np.asarray(t, dtype=float), a_b=params.a_b, gamma=params.gamma)

def field_equation_residuals(t, state, params: ModelParameters):
    """Template: return residuals of the actual independent field equations.

    Parameters
    ----------
    t : array-like
        Cosmic time.
    state : dict
        Expected keys depend on your model, e.g. a, H, rho, p, R, T.
    params : ModelParameters
        Model parameters.

    Returns
    -------
    dict
        Empty by design. Add entries such as `00_equation`, `ii_equation`,
        and `trace_equation`, each an array of residuals. Do not interpret an
        empty result as validation.
    """
    raise NotImplementedError(
        "Derive the exact f(R,T) field equations and implement their residuals here."
    )
