"""Interactive dashboard for the illustrative bounce pipeline."""
from pathlib import Path
import sys
import streamlit as st
import pandas as pd
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from simulation.numerical_solver import solve_background

st.set_page_config(page_title="Cosmology ML Lab", layout="wide")
st.title("Cosmology ML Research Lab")
st.warning(
    "Demonstration only: plots use a phenomenological bounce ansatz, not a verified "
    "solution of f(R,T) field equations. rho, p, and w are intentionally undefined."
)
st.markdown("Explore the kinematic pipeline, then replace the ansatz with your derived field-equation solver.")

c1, c2, c3 = st.columns(3)
with c1:
    a_b = st.number_input("Bounce scale factor a_b", min_value=0.01, value=1.0, step=0.1)
with c2:
    gamma = st.number_input("Bounce parameter gamma", min_value=0.001, value=0.5, step=0.1)
with c3:
    lam = st.number_input("Placeholder coupling lambda", value=0.1, step=0.05)

t_min, t_max = st.slider("Time range", min_value=-20.0, max_value=20.0, value=(-5.0, 5.0), step=0.5)
n = st.slider("Number of time points", min_value=101, max_value=2001, value=501, step=100)

df = solve_background(t_min, t_max, n, a_b, gamma, lam)
left, right = st.columns(2)
with left:
    st.plotly_chart(px.line(df, x="t", y="a", title="Scale factor a(t)"), use_container_width=True)
    st.plotly_chart(px.line(df, x="t", y="H", title="Hubble parameter H(t)"), use_container_width=True)
with right:
    st.plotly_chart(px.line(df, x="t", y="Hdot", title="Hubble derivative dH/dt"), use_container_width=True)
    st.plotly_chart(px.line(df, x="t", y="R_flat_FLRW_illustration", title="Illustrative flat-FLRW Ricci scalar"), use_container_width=True)

st.subheader("Data preview")
st.dataframe(df.head(30), use_container_width=True)
csv = df.to_csv(index=False).encode("utf-8")
st.download_button("Download current CSV", data=csv, file_name="cosmology_kinematics.csv", mime="text/csv")

st.info("Next scientific step: derive and implement the exact gravitational field equations in equations/field_equations.py and simulation/numerical_solver.py.")
