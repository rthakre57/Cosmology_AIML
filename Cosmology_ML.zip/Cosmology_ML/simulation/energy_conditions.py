"""Perfect-fluid energy-condition diagnostics.

Use only after rho and p have been derived consistently. For anisotropic
fluids, replace p with the relevant directional pressures and apply the
appropriate tensor-level conditions. Modified-gravity effective conditions
must be clearly distinguished from matter-sector conditions.
"""
import numpy as np
import pandas as pd

def energy_condition_table(rho, p, atol=1e-10):
    rho, p = np.broadcast_arrays(np.asarray(rho, float), np.asarray(p, float))
    return pd.DataFrame({
        "NEC_rho_plus_p": rho + p,
        "WEC_rho": rho,
        "WEC_rho_plus_p": rho + p,
        "SEC_rho_plus_3p": rho + 3.0*p,
        "SEC_rho_plus_p": rho + p,
        "DEC_rho": rho,
        "DEC_rho_minus_abs_p": rho - np.abs(p),
        "NEC_satisfied": (rho + p) >= -atol,
        "WEC_satisfied": (rho >= -atol) & ((rho+p) >= -atol),
        "SEC_satisfied": ((rho+3*p) >= -atol) & ((rho+p) >= -atol),
        "DEC_satisfied": (rho >= np.abs(p) - atol),
    })

def add_energy_conditions(df):
    if not {"rho", "p"}.issubset(df.columns):
        raise ValueError("DataFrame must contain rho and p columns.")
    if df[["rho", "p"]].isna().any().any():
        raise ValueError("rho/p contain NaN. Derive them from your model first.")
    ec = energy_condition_table(df["rho"], df["p"])
    return pd.concat([df.reset_index(drop=True), ec.reset_index(drop=True)], axis=1)
