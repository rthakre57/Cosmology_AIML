"""Phenomenological symmetric-bounce functions for pipeline testing.

This is a kinematic ansatz, not a solution guaranteed by any gravity theory:
    a(t) = a_b * (1 + gamma*t**2)**(1/3)
It has a positive minimum at t=0 for a_b>0 and gamma>0.
"""
import numpy as np

def scale_factor(t, a_b=1.0, gamma=0.5):
    t = np.asarray(t, dtype=float)
    if a_b <= 0 or gamma <= 0:
        raise ValueError("a_b and gamma must be positive.")
    return a_b * (1.0 + gamma * t**2) ** (1.0 / 3.0)

def hubble_parameter(t, gamma=0.5):
    """H = adot/a = 2 gamma t / [3(1 + gamma t^2)]."""
    t = np.asarray(t, dtype=float)
    if gamma <= 0:
        raise ValueError("gamma must be positive.")
    return (2.0 * gamma * t) / (3.0 * (1.0 + gamma * t**2))

def hubble_derivative(t, gamma=0.5):
    """Time derivative of H."""
    t = np.asarray(t, dtype=float)
    if gamma <= 0:
        raise ValueError("gamma must be positive.")
    return (2.0 * gamma * (1.0 - gamma * t**2)) / (
        3.0 * (1.0 + gamma * t**2) ** 2
    )

def deceleration_parameter(t, gamma=0.5):
    """q = -1 - Hdot/H^2; undefined at H=0, so returns NaN there."""
    t = np.asarray(t, dtype=float)
    H = hubble_parameter(t, gamma)
    Hd = hubble_derivative(t, gamma)
    q = np.full_like(H, np.nan, dtype=float)
    mask = np.abs(H) > 1e-12
    q[mask] = -1.0 - Hd[mask] / H[mask]**2
    return q

def bounce_background(t, a_b=1.0, gamma=0.5):
    t = np.asarray(t, dtype=float)
    a = scale_factor(t, a_b, gamma)
    H = hubble_parameter(t, gamma)
    Hd = hubble_derivative(t, gamma)
    q = deceleration_parameter(t, gamma)
    # Flat FLRW Ricci scalar convention R = 6(Hdot + 2H^2), for illustration only.
    R = 6.0 * (Hd + 2.0 * H**2)
    return {"t": t, "a": a, "H": H, "Hdot": Hd, "q": q, "R_flat_FLRW_illustration": R}
