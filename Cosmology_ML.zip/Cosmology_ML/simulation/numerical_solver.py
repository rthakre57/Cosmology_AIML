"""Generate a background time grid and derived kinematic quantities."""
import numpy as np
import pandas as pd
from simulation.scale_factor import bounce_background

def solve_background(t_min=-5.0, t_max=5.0, n_points=1001,
                     a_b=1.0, gamma=0.5, lam=0.1):
    if t_max <= t_min:
        raise ValueError("t_max must exceed t_min.")
    if n_points < 3:
        raise ValueError("n_points must be at least 3.")
    t = np.linspace(t_min, t_max, n_points)
    values = bounce_background(t, a_b=a_b, gamma=gamma)
    df = pd.DataFrame(values)
    df["a_b"] = a_b
    df["gamma"] = gamma
    df["lambda"] = lam
    # Explicit placeholders: rho and p require field equations/matter assumptions.
    df["rho"] = np.nan
    df["p"] = np.nan
    df["w"] = np.nan
    return df

if __name__ == "__main__":
    df = solve_background()
    print(df.head())
    print("\nThis is kinematic-only data. rho, p and w are intentionally undefined.")
