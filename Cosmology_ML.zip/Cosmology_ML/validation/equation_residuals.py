"""Numerical utilities for checking a model's equations.

The actual gravity residuals cannot be computed until the field equations are
derived and implemented in equations/field_equations.py.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

def finite_difference_derivative(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    if x.ndim != 1 or y.ndim != 1 or len(x) != len(y):
        raise ValueError("x and y must be 1-D arrays of equal length.")
    return np.gradient(y, x, edge_order=2)

def compare_hubble_with_scale_factor(df):
    """Check H against numerical derivative adot/a."""
    t, a, H = df["t"].to_numpy(), df["a"].to_numpy(), df["H"].to_numpy()
    H_fd = finite_difference_derivative(t, a) / a
    return pd.DataFrame({"t": t, "H_analytic": H, "H_from_a_finite_difference": H_fd,
                         "absolute_error": np.abs(H - H_fd)})

def main():
    path = ROOT / "dataset" / "generated" / "cosmology_dataset.csv"
    if not path.exists():
        from dataset.generate_dataset import generate_dataset
        df = generate_dataset()
    else:
        df = pd.read_csv(path)
    # One parameter combination for a concise diagnostic.
    first = df[(df["a_b"] == df["a_b"].iloc[0]) &
               (df["gamma"] == df["gamma"].iloc[0]) &
               (df["lambda"] == df["lambda"].iloc[0])].copy()
    result = compare_hubble_with_scale_factor(first)
    out = ROOT / "results" / "tables" / "kinematic_residuals.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(out, index=False)
    print(result["absolute_error"].describe())
    print("\nThis checks the kinematic identity only, not the modified-gravity field equations.")

if __name__ == "__main__":
    main()
