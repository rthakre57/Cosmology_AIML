"""Compare phenomenological bounce parameter settings.

This does NOT compare different gravity theories. Each theory needs its own
derived and validated field-equation solver before theory-level comparison.
"""
from pathlib import Path
import pandas as pd
from simulation.numerical_solver import solve_background

ROOT = Path(__file__).resolve().parents[1]

def main():
    df_a = solve_background(gamma=0.2)
    df_b = solve_background(gamma=0.8)
    df_a["scenario"] = "gamma=0.2"
    df_b["scenario"] = "gamma=0.8"
    combined = pd.concat([df_a, df_b], ignore_index=True)
    out = ROOT / "results" / "tables" / "phenomenological_comparison.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    combined.to_csv(out, index=False)
    summary = combined.groupby("scenario").agg(
        a_min=("a", "min"), a_max=("a", "max"),
        H_min=("H", "min"), H_max=("H", "max")
    )
    print(summary)
    print("\nThis compares two kinematic ansatz parameter settings, not gravity theories.")

if __name__ == "__main__":
    main()
