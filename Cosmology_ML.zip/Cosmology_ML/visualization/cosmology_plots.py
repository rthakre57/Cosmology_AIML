"""Create background and energy-condition plots from generated data."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "dataset" / "generated" / "cosmology_dataset.csv"
FIGS = ROOT / "results" / "figures"

def main():
    if not DATA.exists():
        from dataset.generate_dataset import generate_dataset
        generate_dataset()
    df = pd.read_csv(DATA)
    FIGS.mkdir(parents=True, exist_ok=True)
    key = df[["a_b", "gamma", "lambda"]].drop_duplicates().iloc[0]
    one = df[(df.a_b == key.a_b) & (df.gamma == key.gamma) & (df["lambda"] == key["lambda"])].sort_values("t")
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    axes[0, 0].plot(one.t, one.a)
    axes[0, 0].set(title="Scale factor (phenomenological ansatz)", xlabel="t", ylabel="a(t)")
    axes[0, 1].plot(one.t, one.H)
    axes[0, 1].axhline(0, linewidth=0.8)
    axes[0, 1].set(title="Hubble parameter", xlabel="t", ylabel="H(t)")
    axes[1, 0].plot(one.t, one.Hdot)
    axes[1, 0].axhline(0, linewidth=0.8)
    axes[1, 0].set(title="Time derivative of H", xlabel="t", ylabel="dH/dt")
    axes[1, 1].plot(one.t, one["R_flat_FLRW_illustration"])
    axes[1, 1].set(title="Illustrative flat-FLRW Ricci scalar", xlabel="t", ylabel="R(t)")
    fig.tight_layout()
    fig.savefig(FIGS / "background_evolution.png", dpi=160)
    plt.close(fig)

    # Energy conditions cannot be plotted until rho and p are supplied.
    if df[["rho", "p"]].notna().all().all():
        from simulation.energy_conditions import energy_condition_table
        ec = energy_condition_table(df["rho"], df["p"])
        fig, ax = plt.subplots(figsize=(10, 5))
        for col in ["NEC_rho_plus_p", "SEC_rho_plus_3p", "DEC_rho_minus_abs_p"]:
            ax.plot(df.t, ec[col], label=col)
        ax.axhline(0, linewidth=0.8)
        ax.legend()
        ax.set(xlabel="t", ylabel="condition expression", title="Energy-condition diagnostics")
        fig.tight_layout()
        fig.savefig(FIGS / "energy_conditions.png", dpi=160)
        plt.close(fig)
    else:
        print("Skipped energy-condition plot: rho and p are not implemented.")

    pred_path = ROOT / "results" / "tables" / "random_forest_predictions.csv"
    if pred_path.exists():
        pred = pd.read_csv(pred_path)
        fig, ax = plt.subplots(figsize=(6, 6))
        ax.scatter(pred.actual_H, pred.predicted_H, s=12)
        lo = min(pred.actual_H.min(), pred.predicted_H.min())
        hi = max(pred.actual_H.max(), pred.predicted_H.max())
        ax.plot([lo, hi], [lo, hi], linestyle="--")
        ax.set(xlabel="Numerical H", ylabel="ML-predicted H", title="Random Forest predictions")
        fig.tight_layout()
        fig.savefig(FIGS / "ml_predictions.png", dpi=160)
        plt.close(fig)
    print(f"Plots saved in {FIGS}")

if __name__ == "__main__":
    main()
