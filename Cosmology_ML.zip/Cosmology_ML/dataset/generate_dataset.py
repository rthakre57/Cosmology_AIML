"""Generate a grid of phenomenological bounce kinematics for ML pipeline tests.

The data are synthetic and do not represent observational data or a verified
solution of f(R,T) gravity. rho, p and w are not fabricated.
"""
from pathlib import Path
import itertools
import numpy as np
import pandas as pd
from simulation.numerical_solver import solve_background

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dataset" / "generated" / "cosmology_dataset.csv"

def generate_dataset(t_min=-5, t_max=5, n_points=301,
                     a_b_values=(0.8, 1.0, 1.2),
                     gamma_values=(0.2, 0.5, 0.8),
                     lambda_values=(-0.2, 0.0, 0.2)):
    frames = []
    for a_b, gamma, lam in itertools.product(a_b_values, gamma_values, lambda_values):
        df = solve_background(t_min, t_max, n_points, a_b, gamma, lam)
        frames.append(df)
    combined = pd.concat(frames, ignore_index=True)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    combined.to_csv(OUT, index=False)
    print(f"Saved {len(combined)} rows to {OUT}")
    print("Note: rho, p, and w remain NaN until a physical field-equation model is implemented.")
    return combined

if __name__ == "__main__":
    generate_dataset()
