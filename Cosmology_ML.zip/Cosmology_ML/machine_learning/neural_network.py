"""PyTorch neural-network regression baseline for H(t)."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "dataset" / "generated" / "cosmology_dataset.csv"
METRICS = ROOT / "results" / "tables" / "neural_network_metrics.json"
MODEL_PATH = ROOT / "results" / "tables" / "neural_network.pt"

class Regressor(nn.Module):
    def __init__(self, n_features):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_features, 64), nn.Tanh(),
            nn.Linear(64, 64), nn.Tanh(),
            nn.Linear(64, 1)
        )
    def forward(self, x):
        return self.net(x)

def main(epochs=300, learning_rate=1e-3):
    if not DATA.exists():
        from dataset.generate_dataset import generate_dataset
        generate_dataset()
    df = pd.read_csv(DATA)
    features, target = ["t", "a_b", "gamma", "lambda"], "H"
    data = df[features + [target]].dropna()
    groups = data[["a_b", "gamma", "lambda"]].astype(str).agg("_".join, axis=1)
    train_idx, test_idx = next(GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=42)
                               .split(data[features], data[target], groups))
    X_train, X_test = data.iloc[train_idx][features].to_numpy(), data.iloc[test_idx][features].to_numpy()
    y_train, y_test = data.iloc[train_idx][target].to_numpy().reshape(-1, 1), data.iloc[test_idx][target].to_numpy().reshape(-1, 1)
    sx, sy = StandardScaler(), StandardScaler()
    X_train_s, X_test_s = sx.fit_transform(X_train), sx.transform(X_test)
    y_train_s, y_test_s = sy.fit_transform(y_train), sy.transform(y_test)
    torch.manual_seed(42)
    model = Regressor(X_train_s.shape[1])
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    loss_fn = nn.MSELoss()
    xt = torch.tensor(X_train_s, dtype=torch.float32)
    yt = torch.tensor(y_train_s, dtype=torch.float32)
    model.train()
    for _ in range(epochs):
        optimizer.zero_grad()
        loss = loss_fn(model(xt), yt)
        loss.backward()
        optimizer.step()
    model.eval()
    with torch.no_grad():
        pred_s = model(torch.tensor(X_test_s, dtype=torch.float32)).numpy()
    pred = sy.inverse_transform(pred_s).ravel()
    actual = y_test.ravel()
    metrics = {
        "target": target, "epochs": epochs, "test_rows": int(len(actual)),
        "mae": float(mean_absolute_error(actual, pred)),
        "rmse": float(mean_squared_error(actual, pred) ** 0.5),
        "r2": float(r2_score(actual, pred)),
        "scope_note": "Synthetic phenomenological kinematics only; not a validated gravity solution."
    }
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "features": features,
                "x_mean": sx.mean_.tolist(), "x_scale": sx.scale_.tolist(),
                "y_mean": sy.mean_.tolist(), "y_scale": sy.scale_.tolist()}, MODEL_PATH)
    METRICS.write_text(json.dumps(metrics, indent=2))
    pd.DataFrame({"actual_H": actual, "predicted_H": pred}).to_csv(
        ROOT / "results" / "tables" / "neural_network_predictions.csv", index=False)
    print(json.dumps(metrics, indent=2))

if __name__ == "__main__":
    main()
