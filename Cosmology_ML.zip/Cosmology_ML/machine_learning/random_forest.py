"""Random Forest baseline for the synthetic kinematic dataset."""
from pathlib import Path
import json
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import joblib

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "dataset" / "generated" / "cosmology_dataset.csv"
OUT_MODEL = ROOT / "results" / "tables" / "random_forest_model.joblib"
OUT_METRICS = ROOT / "results" / "tables" / "random_forest_metrics.json"

def main():
    if not DATA.exists():
        from dataset.generate_dataset import generate_dataset
        df = generate_dataset()
    else:
        df = pd.read_csv(DATA)
    features = ["t", "a_b", "gamma", "lambda"]
    target = "H"
    data = df[features + [target]].dropna()
    # Hold out complete parameter combinations to reduce row leakage.
    groups = data[["a_b", "gamma", "lambda"]].astype(str).agg("_".join, axis=1)
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=42)
    train_idx, test_idx = next(splitter.split(data[features], data[target], groups))
    X_train, X_test = data.iloc[train_idx][features], data.iloc[test_idx][features]
    y_train, y_test = data.iloc[train_idx][target], data.iloc[test_idx][target]
    model = make_pipeline(
        SimpleImputer(strategy="median"),
        RandomForestRegressor(n_estimators=250, random_state=42, n_jobs=-1)
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    metrics = {
        "target": target,
        "test_rows": int(len(test_idx)),
        "mae": float(mean_absolute_error(y_test, pred)),
        "rmse": float(mean_squared_error(y_test, pred) ** 0.5),
        "r2": float(r2_score(y_test, pred)),
        "scope_note": "Synthetic phenomenological kinematics only; not a validated gravity solution."
    }
    OUT_MODEL.parent.mkdir(parents=True, exist_ok=True)
    import joblib
    joblib.dump(model, OUT_MODEL)
    OUT_METRICS.write_text(json.dumps(metrics, indent=2))
    pd.DataFrame({"actual_H": y_test.to_numpy(), "predicted_H": pred}).to_csv(
        ROOT / "results" / "tables" / "random_forest_predictions.csv", index=False
    )
    print(json.dumps(metrics, indent=2))

if __name__ == "__main__":
    main()
