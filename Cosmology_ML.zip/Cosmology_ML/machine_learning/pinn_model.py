"""PINN template.

This example demonstrates automatic differentiation and a residual loss for
the *illustrative kinematic identity* H = adot/a. It is NOT a PINN solution
of the f(R,T) field equations. Replace/add residuals from the actual derived
gravitational equations before using it in research.
"""
import torch
from torch import nn

class BounceKinematicsPINN(nn.Module):
    def __init__(self, hidden=64, depth=3):
        super().__init__()
        layers = [nn.Linear(1, hidden), nn.Tanh()]
        for _ in range(depth - 1):
            layers += [nn.Linear(hidden, hidden), nn.Tanh()]
        layers += [nn.Linear(hidden, 2)]  # predicts a(t), H(t)
        self.net = nn.Sequential(*layers)

    def forward(self, t):
        out = self.net(t)
        a = torch.nn.functional.softplus(out[:, 0:1]) + 1e-6
        H = out[:, 1:2]
        return a, H

def kinematic_residual_loss(model, t):
    """Loss for H=adot/a only. This does not enforce a gravity field equation."""
    t = t.clone().detach().requires_grad_(True)
    a, H = model(t)
    adot = torch.autograd.grad(a.sum(), t, create_graph=True)[0]
    residual = H - adot / a
    return torch.mean(residual**2)

def gravity_residual_loss(model, t, parameters):
    """Implement residuals of the actual independent field equations here."""
    raise NotImplementedError(
        "Insert derived f(R,T) (or other theory) field-equation residuals; "
        "the kinematic identity alone is not a physical PINN."
    )
