# Cosmology_ML

A modular Python starter project for exploring cosmological background dynamics, ML surrogate models, PINN-style equation residuals, energy-condition diagnostics, validation, plots, and a Streamlit dashboard.

## Scientific scope and important limitation

This is a **runnable research scaffold**, not a verified implementation of the full Bianchi Type-I field equations for `f(R,T)=R+2 lambda T`. The included background is an explicitly labelled **phenomenological symmetric bounce**:

`a(t) = a_b (1 + gamma t^2)^(1/3)`

It is used to test the software pipeline. It is **not** claimed to solve the modified-gravity field equations. The field-equation residual module is a template until you derive and enter the exact equations for your chosen metric, matter Lagrangian, sign conventions, and assumptions.

The standard perfect-fluid energy-condition expressions are included as diagnostics only. For anisotropic matter, use directional pressures; for modified gravity, state whether conditions are applied to matter or an effective stress-energy tensor.

## Install

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## Run the pipeline

From the project root:

```bash
python -m dataset.generate_dataset
python -m machine_learning.random_forest
python -m machine_learning.neural_network
python -m validation.equation_residuals
python -m validation.model_comparison
python -m visualization.cosmology_plots
streamlit run dashboard/app.py
```

Outputs are written to `results/figures/`, `results/tables/`, and `dataset/generated/`.

## Project modules

- `equations/field_equations.py`: replaceable model/equation interface and sample bounce kinematics.
- `simulation/scale_factor.py`: phenomenological bounce functions and derivatives.
- `simulation/numerical_solver.py`: time-grid generation and derived background variables.
- `simulation/energy_conditions.py`: perfect-fluid energy-condition diagnostics.
- `dataset/generate_dataset.py`: parameter-grid dataset generation.
- `machine_learning/random_forest.py`: scikit-learn regression baseline.
- `machine_learning/neural_network.py`: PyTorch neural-network regression baseline.
- `machine_learning/pinn_model.py`: PINN-style template with an example residual; replace it with derived field equations before scientific use.
- `validation/equation_residuals.py`: placeholder residual checks and numerical derivative utilities.
- `validation/model_comparison.py`: compares two phenomenological parameter settings, not different gravity theories.
- `visualization/cosmology_plots.py`: creates plots from generated data.
- `dashboard/app.py`: interactive Streamlit dashboard.

## Reproducibility and research checklist

Before making scientific claims:
1. Derive field equations from a clearly stated action and matter Lagrangian.
2. Document metric signature, units, conventions, and definitions of `T` and `R`.
3. Verify analytical solutions by substitution into every independent field equation.
4. Check numerical convergence and compare against an independent solver.
5. Separate training, validation, and held-out test sets by parameter combinations (not random rows only).
6. For PINNs, use actual equation residuals, initial/boundary conditions, and report each loss component.
7. For observational constraints, implement the model's observable predictions and a justified likelihood; do not fit synthetic outputs as if they were observations.
8. Record parameter priors, data provenance, uncertainties, and code versions.

## Expected generated files

- `dataset/generated/cosmology_dataset.csv`
- `results/tables/random_forest_metrics.json`
- `results/tables/neural_network_metrics.json`
- `results/figures/background_evolution.png`
- `results/figures/energy_conditions.png`
- `results/figures/ml_predictions.png`

## Dependencies

See `requirements.txt`. The PINN template uses PyTorch, which is included.
